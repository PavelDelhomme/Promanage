from app.database import get_db

__all__ = ["get_db"] # Exporte la fonction