from sqlalchemy import Column, Integer, String, Boolean
from app.database import Base

class AdminUser(Base):
    __tablename__ = "admin_users"

    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True)
    hashed_password = Column(String(300))
    is_superuser = Column(Boolean, default=False)