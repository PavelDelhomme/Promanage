from sqlalchemy import Column, Integer, String, Enum, Date, Text, JSON, Boolean
from datetime import date
from app.database import Base


class CVEntry(Base):
    __tablename__ = "cv_entries"

    id = Column(Integer, primary_key=True)
    entry_type = Column(String(20))  # experience/education/certification/skills
    title = Column(String(100))
    description = Column(Text)
    organization = Column(String(100))  # Entreprise/École
    location = Column(String(100)) # Localisation
    start_date = Column(Date)
    end_date = Column(Date)
    skills = Column(Text) # JSON: {"backend": ["Python", "Java"], ...}
    languages = Column(JSON) # {"Anglais": "B2", "Russe": "A2"}
    interests = Column(Text) # 'Lecture, Sport, Musique"
    technical_skills = Column(JSON) # {"DevOps": ["Docker", "Nginx"], ...}
    certifications = Column(Text)
    github_url = Column(String(200))
    url = Column(String(200))
    is_public = Column(Boolean, default=False)
