from sqlalchemy import Column, Integer, String, Enum, Text, DateTime
from app.database import Base
from sqlalchemy.sql import func

class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True)
    title = Column(String(100))
    description = Column(Text)
    status = Column(Enum('draft', 'published', 'archived', name='status_enum'))
    category = Column(String(50))
    start_date = Column(DateTime)
    end_date = Column(DateTime)
