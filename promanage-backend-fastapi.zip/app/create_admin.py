import os
from sqlalchemy.orm import Session
from app.core.security import get_password_hash
from app.db.session import get_db
from app.models.user import AdminUser
from dotenv import load_dotenv

load_dotenv()

def create_admin():
    db: Session = next(get_db())
    admin = AdminUser(
        username=os.getenv("ADMIN_USERNAME"),
        password=get_password_hash(os.getenv("ADMIN_INIT_PASSWORD")),
        is_superuser=True
    )
    try:
        db.commit()
        print("\u2705 Admin créé avec succès")
    except Exception as e:
        db.rollback()
        print(f"\u274c Erreur création admin : {e}")

if __name__ == "__main__":
    create_admin()
