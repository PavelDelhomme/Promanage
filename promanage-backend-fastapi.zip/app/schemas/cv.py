from pydantic import BaseModel
from datetime import date
from typing import Optional, Dict, List

class CVEntryBase(BaseModel):
    entry_type: str
    title: str
    description: Optional[str] = None
    organization: Optional[str] = None
    location: Optional[str] = None
    company: Optional[str] = None
    start_date: date
    end_date: Optional[date] = None
    skills: Optional[Dict[str, List[str]]] = None
    url: Optional[str] = None
    languages: Optional[Dict[str, str]] = None
    technical_skills: Optional[Dict[str, List[str]]] = None
    certifications: Optional[str] = None
    github_url: Optional[str] = None
    is_public: bool = False

class CVEntryCreate(CVEntryBase):
    pass

class CVEntry(CVEntryBase):
    id: int

    class Config:
        orm_mode = True